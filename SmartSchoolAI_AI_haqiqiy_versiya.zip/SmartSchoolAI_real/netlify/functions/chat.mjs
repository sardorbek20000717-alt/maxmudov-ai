export default async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json; charset=utf-8",
  };
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Faqat POST so‘rovi mumkin." }), { status: 405, headers: cors });
  const apiKey = Netlify.env.get("OPENAI_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "OPENAI_API_KEY Netlify environment variables sozlamasiga qo‘shilmagan." }), { status: 503, headers: cors });
  try {
    const body = await req.json();
    const message = typeof body.message === "string" ? body.message.trim() : "";
    if (!message) return new Response(JSON.stringify({ error: "Savol yozing." }), { status: 400, headers: cors });
    if (message.length > 5000) return new Response(JSON.stringify({ error: "Savol juda uzun (maksimum 5000 belgi)." }), { status: 413, headers: cors });
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: "Sen Smart School AI nomli o‘quv yordamchisisan. O‘zbek tilida sodda, yosh o‘quvchilarga mos va aniq javob ber. Maktab fanlarini bosqichma-bosqich tushuntir, hisob-kitoblarni tekshir, bilmagan narsangni to‘qib chiqarmagin. Kerak bo‘lsa foydalanuvchidan savolni aniqlashtir. Xavfsiz va hurmatli bo‘l.",
        input: message,
        max_output_tokens: 1200
      })
    });
    const payload = await upstream.json();
    if (!upstream.ok) {
      const safeMessage = upstream.status === 401 ? "API kaliti noto‘g‘ri yoki bekor qilingan." : upstream.status === 429 ? "API limiti yoki billing holatini tekshiring." : "OpenAI API so‘rovni bajara olmadi. API sozlamalarini tekshiring.";
      return new Response(JSON.stringify({ error: safeMessage }), { status: upstream.status === 429 ? 429 : 502, headers: cors });
    }
    const reply = (payload.output || []).flatMap(item => item.content || []).filter(item => item.type === "output_text").map(item => item.text).join("\n").trim();
    return new Response(JSON.stringify({ reply: reply || "Javob olinmadi. Qayta urinib ko‘ring." }), { status: 200, headers: cors });
  } catch {
    return new Response(JSON.stringify({ error: "Server xatosi. Keyinroq qayta urinib ko‘ring." }), { status: 500, headers: cors });
  }
};
