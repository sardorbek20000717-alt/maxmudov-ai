SMART SCHOOL AI — AI YORDAMCHI QO‘SHILGAN VERSIYA

NIMALAR QO‘SHILDI
- Saytda “AI yordamchi” bo‘limi.
- AI savollarini Netlify Function orqali OpenAI API’ga yuborish.
- API kaliti brauzerga yuborilmaydi; Netlify environment variable’da saqlanadi.
- Model: gpt-4.1-mini.

NETLIFY’GA JOYLASH
1. ZIP ichidagi fayllarni chiqar. index.html, netlify.toml va netlify papkasi bir joyda bo‘lsin.
2. Netlify’da yangi site yarat yoki mavjud saytingni Git repository orqali deploy qil. Netlify Functions ishlashi uchun bu papkalar build/deploy ichida qolishi kerak. Oddiy manual drag-and-drop deploy’da function build qilinmasligi mumkin; eng ishonchli usul — GitHub repository ulab deploy qilish.
3. Netlify: Site configuration / Environment variables (yoki Project configuration → Environment variables) bo‘limiga kir.
4. Yangi variable yarating: key = OPENAI_API_KEY, value = OpenAI platformasida yaratilgan yangi API kalit.
5. Saqla va saytni qayta deploy qil (trigger deploy).
6. Saytda AI yordamchi bo‘limini ochib sinab ko‘r.

XAVFSIZLIK
- API kalitini index.html, JavaScript fayli, GitHub kodi yoki chatga yozmang.
- Oldin chatga yuborilgan kalitni revoke qiling; u oshkor bo‘lgan hisoblanadi.
- OpenAI API billing/limit sozlamalari kerak bo‘lishi mumkin. ChatGPT obunasi API kreditlarini bermaydi.
- Xarajat limitini platformada sozlang va kalitni faqat kerakli loyihada ishlating.

MUHIM CHEKLOVLAR
- Ushbu versiya AI chatni qo‘shadi, lekin Google/Firebase login hali ulanmagan.
- Tangalar hozircha demo/localStorage bo‘lishi mumkin; xavfsiz haqiqiy coin/buyurtma tizimi uchun Firebase/DB va server-side tekshiruv kerak.
- Kitob nomlari va ayrim dars/test ma’lumotlari prototip; hamma sinflar/fanlar uchun to‘liq, tekshirilgan kontent emas.
